function setup() { "use strict";
  var canvas = document.getElementById('myCanvas');
  //
  var ctx = canvas.getContext('2d');
  var slider1 = document.getElementById('slider1');
  slider1.value = 0;
  var slider2 = document.getElementById('slider2');
  slider2.value = 0;
  var slider3 = document.getElementById('slider3');
  slider3.value = 0;
  var slider4 = document.getElementById('slider4');
  slider4.value = 0;
  var slider5 = document.getElementById('slider5');
  slider4.value = 0;
  var frameCounter = 0;
  var th1 = -35;
  var cf1 = -35;
  var ft1 = -35;
  var th2 = 0;
  var cf2 = 0;
  var ft2 = 0;
  var xval = 4;
  var yval = 0;

  function draw(){
    
    canvas.width = canvas.width;
    var ftlg = th1*Math.PI/180;
    var ftcf = cf1*Math.PI/180;
    var ftft = ft1*Math.PI/180;
    var bclg = th2*Math.PI/180;
    var bccf = cf2*Math.PI/180;
    var bcft = ft2*Math.PI/180;
    var wist = slider1.value*Math.PI/180;
    var tail = slider2.value*Math.PI/180;
    var ear = slider3.value*Math.PI/180;
    var neck_ = slider4.value*Math.PI/180;
    var head_ = slider5.value*Math.PI/180;
    

    function moveToTx(x,y,Tx)
	  {var res=vec2.create(); vec2.transformMat3(res,[x,y],Tx); ctx.moveTo(res[0],res[1]);}

	  function lineToTx(x,y,Tx)
	  {var res=vec2.create(); vec2.transformMat3(res,[x,y],Tx); ctx.lineTo(res[0],res[1]);}

    function animationHandler(){
      if(frameCounter == 0){
        cf1+=2;
        //ft1--;
        th2--;
        ft2++;
        if(cf1==35){
          frameCounter = 1;
          //break;
        }
      }else if(frameCounter == 1){
        
        th1+=2;
        ft1++;
        ft2-=2;
        cf2--;
        if(th1==35){
          frameCounter = 2;
        }
      }else if(frameCounter ==2){
        th1--;
        cf1--;
        cf2+=2;
        //ft2++;
        if(cf2==35){
          cf1= 0;
          ft1=0;
          th1= 0;
          th2 = -35;
          cf2 = 35;
          ft2 = -35;
          frameCounter = 3;
        }
      }else{
        th1--;
        th2 ++;
        cf1 --;
        ft1--;
        ft2 ++;
        cf2--;
        if(cf1==-35){
          frameCounter = 0;
        }
      }

      xval++;
      if(xval >= canvas.width){
        xval = 4;
      }
      yval = 1000/2 + 20 * Math.sin((xval+4)/50);

      window.requestAnimationFrame(draw);
    }

    function Tree(color, Tx){
      ctx.beginPath();
      ctx.fillStyle = color;
      moveToTx(0, 0, Tx); lineToTx(10, 0, Tx); lineToTx(20, -40, Tx);lineToTx(30, -40, Tx); 
      lineToTx(0, -70, Tx); lineToTx(-30, -40, Tx); lineToTx(-20, -40, Tx); lineToTx(-10, 0, Tx);
      ctx.closePath();
      ctx.fill();
    }

    /*function sinTrack(){
      //var x = 4;
     
      window.requestAnimationFrame(draw);
      //return(xval, yval+500);
    }*/

    function drawSin(xos){
      ctx.beginPath();
      var x = 4;
      var y = 0;

      var amp = 20;
      var freq = 50;
      while (x <  canvas.width) {
        y = 1000/2 + amp * Math.sin((x+xos)/freq);
        ctx.lineTo(x, y);
        x++;
        // console.log("x="+x+" y="+y);
    }
    ctx.stroke();
    }
      
    function thigh(color, Tx){
      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.strokeStyle = "white";
      moveToTx(345-345,460-460,Tx);lineToTx(375-345, 450-460, Tx);lineToTx(405-345, 460-460, Tx);lineToTx(405-345, 570-460, Tx);
      lineToTx(385-345, 570-460, Tx);lineToTx(355-345, 520-460, Tx);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      /*ctx.beginPath();
      ctx.strokeStyle = "yellow";
      ctx.moveTo(375-345, 470-460); ctx.lineTo(365-345, 480-460); ctx.lineTo(375-345, 490-460); ctx.lineTo(385-345, 480-460);
      ctx.lineWidth = 3;
      ctx.closePath();
      ctx.stroke();*/
    }

    function calf(color,Tx){
      ctx.beginPath();
      ctx.fillStyle = color;
      moveToTx(385-385, 550-550, Tx);lineToTx(405-385, 560-550, Tx); lineToTx(360-385, 650-550,Tx); lineToTx(345-385, 645-550, Tx);
      ctx.closePath();
      ctx.fill();
    }

    function body(color, Tx){
      ctx.beginPath();
      ctx.fillStyle = color;
      moveToTx(195-195,445-445,Tx); lineToTx(315-195, 460-445,Tx);lineToTx(315-195, 520-445,Tx);lineToTx(225-195, 570-445, Tx);
      lineToTx(180-195, 545-445, Tx);lineToTx(170-195, 525-445, Tx);
      ctx.closePath();
      ctx.fill();
    }

    function waist(color, Tx){
      ctx.beginPath();
      moveToTx(305-305, 460-460, Tx);lineToTx(355-305, 460-460,Tx);lineToTx(355-305, 520-460,Tx);lineToTx(260-305, 545-460, Tx);
      ctx.fillStyle = color;
      ctx.closePath();
      ctx.fill();
    }
    function feet(color, Tx){
      ctx.beginPath();
      ctx.fillStyle = color;
      moveToTx(360-360, 650-650, Tx); lineToTx(320-360, 660-650, Tx); lineToTx(365-360, 660-650, Tx);
      ctx.closePath();
      ctx.fill();
    }
    
    function neck(color, Tx){
      ctx.beginPath();
      ctx.fillStyle = color;
      moveToTx(130-175-30,500-450, Tx);lineToTx(200-175-30, 520-450, Tx);lineToTx(220-175-30, 460-450, Tx);lineToTx(175-175-30,450-450, Tx);
      ctx.closePath();
      ctx.fill();
    }

    function head(color, Tx){
      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.strokeStyle = "white";
      moveToTx(170-60-100,470-500, Tx);
      lineToTx(170-60-100 +40,490-500, Tx); lineToTx(170-60-100-20 +20,490-500, Tx);lineToTx(170-60-100-20,490-500, Tx);lineToTx(130-60-100+40,510-500, Tx);
      lineToTx(70-60-100,510-500, Tx);lineToTx(60-60-100,500-500, Tx); lineToTx(70-60-100,480-500, Tx); lineToTx(80-60-100,430-500, Tx);
      lineToTx(110-60-100,400-500, Tx);
      //lineToTx(110-60-100,400-500, Tx);
      lineToTx(150-100-60,400-500, Tx);lineToTx(180-60-100,430-500, Tx);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      ctx.beginPath();
      ctx.fillStyle= "blue";
      moveToTx(100-60-100, 470-500, Tx); lineToTx(110-60-100, 450-500, Tx); lineToTx(135-60-100, 450-500, Tx); lineToTx(125-60-100, 470-500, Tx);
      ctx.closePath();
      ctx.fill();

      ctx.beginPath();
      ctx.fillStyle = "white";
      moveToTx(110-60-100,450-500, Tx); lineToTx(115-60-100, 460-500, Tx);lineToTx(125-60-100, 460-500, Tx);lineToTx(135-60-100,450-500, Tx);
      ctx.closePath();
      ctx.fill();

      ctx.beginPath();
      ctx.fillStyle = "red";
      moveToTx(75-60-100, 455-500, Tx); lineToTx(95-60-100, 435-500, Tx);lineToTx(95-60-100, 415-500, Tx);lineToTx(80-60-100,430-500, Tx);
      ctx.closePath;
      ctx.lineWidth = 3;
      ctx.fill();
    }

    function earAndTail(color,Tx){
      ctx.beginPath();
      ctx.fillStyle = color;
      moveToTx(165-165, 415-415,Tx); lineToTx(265-165, 315-415,Tx);lineToTx(215-165, 340-415,Tx);
      ctx.closePath();
      ctx.fill();

      /*ctx.beginPath();
      ctx.strokeStyle = "yellow";
      ctx.moveTo(215-165, 365-415); ctx.lineTo(240-165, 328-415);
      ctx.lineWidth = 3;
      ctx.stroke();*/
    }

    drawSin(4);
    var Ttree_to_track = mat3.create();
    //sinTrack();
    mat3.fromTranslation(Ttree_to_track, [xval,yval]);
    Tree("green", Ttree_to_track);
    //var Ttree_to_canvas = mat3.create()

    var Tbody_to_canvas = mat3.create();
    mat3.fromTranslation(Tbody_to_canvas,[345,445]);
    body("pink", Tbody_to_canvas);

    var Tthigh_to_body = mat3.create();
    mat3.fromTranslation(Tthigh_to_body,[0,50]);
    mat3.rotate(Tthigh_to_body, Tthigh_to_body, ftlg);
    var Tthigh_to_canvas = mat3.create();
    mat3.multiply(Tthigh_to_canvas, Tbody_to_canvas, Tthigh_to_body);
    thigh("pink", Tthigh_to_canvas);

    var Tftcf_to_thigh = mat3.create();
    mat3.fromTranslation(Tftcf_to_thigh,[40,110]);
    mat3.rotate(Tftcf_to_thigh, Tftcf_to_thigh, ftcf);
    var Tftcf_to_canvas = mat3.create();
    mat3.multiply(Tftcf_to_canvas, Tthigh_to_canvas, Tftcf_to_thigh);
    calf("pink", Tftcf_to_canvas);

    var Tftft_to_ftcf = mat3.create();
    mat3.fromTranslation(Tftft_to_ftcf,[-30, 100]);
    mat3.rotate(Tftft_to_ftcf, Tftft_to_ftcf, ftft);
    var Tftft_to_canvas = mat3.create();
    mat3.multiply(Tftft_to_canvas, Tftcf_to_canvas, Tftft_to_ftcf);
    feet("pink", Tftft_to_canvas);

    var Tneck_to_body = mat3.create();
    mat3.fromTranslation(Tneck_to_body,[0, 0]);
    mat3.rotate(Tneck_to_body, Tneck_to_body, neck_);
    var Tneck_to_canvas = mat3.create();
    mat3.multiply(Tneck_to_canvas, Tbody_to_canvas, Tneck_to_body);
    neck("pink", Tneck_to_canvas);

    var Thead_to_neck = mat3.create();
    mat3.fromTranslation( Thead_to_neck,[-35,55]);
    mat3.rotate( Thead_to_neck,  Thead_to_neck,head_);
    var Thead_to_canvas = mat3.create();
    mat3.multiply(Thead_to_canvas, Tneck_to_canvas, Thead_to_neck);
    head("pink", Thead_to_canvas);

    /*var Tbrd_to_head = mat3.create();
    mat3.fromTranslation( Tbrd_to_head,[0,-85]);
    mat3.rotate(Tbrd_to_head, Tbrd_to_head,90*Math.PI/180);
    mat3.scale(Tbrd_to_head,Tbrd_to_head,[0.2,1]);
    var Tbrd_to_canvas = mat3.create();
    mat3.multiply(Tbrd_to_canvas, Thead_to_canvas, Tbrd_to_head);
    earAndTail("pink", Tbrd_to_canvas);*/

    

    var Tear_to_head = mat3.create();
    mat3.fromTranslation( Tear_to_head,[0,-85]);
    mat3.rotate( Tear_to_head,  Tear_to_head,ear);
    var Tear_to_canvas = mat3.create();
    mat3.multiply(Tear_to_canvas, Thead_to_canvas, Tear_to_head);
    earAndTail("pink", Tear_to_canvas);

    var Tear_to_ear = mat3.create();
    mat3.fromTranslation( Tear_to_ear,[0,0]);
    mat3.rotate( Tear_to_ear,  Tear_to_ear,15*Math.PI/180);
    mat3.scale(Tear_to_ear,Tear_to_ear,[0.5,1]);
    var Tear1_to_canvas = mat3.create();
    mat3.multiply(Tear1_to_canvas, Tear_to_canvas, Tear_to_ear);
    earAndTail("blue", Tear1_to_canvas);

    var Twaist_to_body = mat3.create();
    mat3.fromTranslation(Twaist_to_body,[110,15]);
    mat3.rotate(Twaist_to_body, Twaist_to_body, wist);
    var Twaist_to_canvas = mat3.create();
    mat3.multiply(Twaist_to_canvas, Tbody_to_canvas, Twaist_to_body);
    waist("pink", Twaist_to_canvas);

    var Tthigh_to_waist = mat3.create();
    mat3.fromTranslation(Tthigh_to_waist,[40,0]);
    mat3.rotate(Tthigh_to_waist, Tthigh_to_waist, bclg);
    var Tthigh1_to_canvas = mat3.create();
    mat3.multiply(Tthigh1_to_canvas, Twaist_to_canvas, Tthigh_to_waist);
    thigh("pink", Tthigh1_to_canvas);

    var Tbccf_to_thigh = mat3.create();
    mat3.fromTranslation(Tbccf_to_thigh,[-20,90]);
    mat3.rotate(Tbccf_to_thigh, Tftcf_to_thigh, bccf);
    var Tbccf_to_canvas = mat3.create();
    mat3.multiply(Tbccf_to_canvas, Tthigh1_to_canvas, Tbccf_to_thigh);
    calf("pink", Tbccf_to_canvas);

    var Tbcft_to_fbccf = mat3.create();
    mat3.fromTranslation(Tbcft_to_fbccf,[-25, 100]);
    mat3.rotate(Tbcft_to_fbccf, Tbcft_to_fbccf, bcft);
    var Tbcft_to_canvas = mat3.create();
    mat3.multiply(Tbcft_to_canvas, Tbccf_to_canvas, Tbcft_to_fbccf);
    feet("pink", Tbcft_to_canvas);

    var Ttail_to_thigh = mat3.create();
    mat3.fromTranslation(Ttail_to_thigh,[60,0]);
    mat3.rotate(Ttail_to_thigh, Ttail_to_thigh, tail);
    mat3.scale(Ttail_to_thigh,Ttail_to_thigh,[2,1]);
    var Ttail_to_canvas = mat3.create();
    mat3.multiply(Ttail_to_canvas, Tthigh1_to_canvas, Ttail_to_thigh);
    earAndTail("pink", Ttail_to_canvas);

    var Ttail_to_tail = mat3.create();
    mat3.fromTranslation(Ttail_to_tail,[40,-50]);
    mat3.rotate(Ttail_to_tail, Ttail_to_tail, tail/2);
    mat3.scale(Ttail_to_tail,Ttail_to_tail,[0.2,1]);
    var Ttail1_to_canvas = mat3.create();
    mat3.multiply(Ttail1_to_canvas, Ttail_to_canvas, Ttail_to_tail);
    earAndTail("pink", Ttail1_to_canvas);


    animationHandler();
    /*ctx.translate(345,445); 
    ctx.save();
    body("black");

    ctx.translate(0,50);
    ctx.save();
    ctx.rotate(ftlg);
    thigh("black");

    ctx.translate(40,110); 
    ctx.save();
    ctx.rotate(ftcf);
    calf("black");

    ctx.translate(-30,100);
    ctx.save();
    ctx.rotate(ftft);
    feet("black");

    ctx.restore();
    ctx.restore();
    ctx.restore();
    ctx.restore();
    ctx.save();
    ctx.translate(-30,0);
    ctx.save();
    ctx.rotate(neck_);
    neck("black");

    ctx.translate(-95,55);
    ctx.save();
    head("black");

    ctx.translate(105,-85);
    ctx.save();
    ctx.rotate(ear);
    earAndTail("black");

    ctx.restore();
    ctx.restore();
    ctx.restore();
    ctx.restore();
    ctx.save();
    ctx.translate(110,15);
    ctx.save();
    ctx.rotate(wist);
    waist("black");

    ctx.translate(40,0);
    ctx.save();
    ctx.rotate(bclg);
    thigh("black");

    ctx.translate(60,0);
    ctx.save();
    ctx.scale(2,1);
    ctx.rotate(tail);
    earAndTail("black");

    ctx.restore();
    //ctx.restore();
    ctx.translate(-20,90);
    ctx.save();
    ctx.rotate(bccf);
    calf("black");

    ctx.translate(-25,100);
    ctx.save();
    ctx.rotate(bcft);
    feet("black");

    ctx.restore();
    ctx.restore();
    ctx.restore();
    ctx.restore();
    ctx.restore();
    animationHandler();*/
    //window.requestAnimationFrame(draw);
  }
  /*slider1.addEventListener("input",draw);
  slider2.addEventListener("input",draw);
  slider3.addEventListener("input",draw);
  slider4.addEventListener("input",draw);*/
  //draw();
  /**/
  window.requestAnimationFrame(draw);
}
window.onload = setup;