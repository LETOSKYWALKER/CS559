function setup(){"use strict";
    var canvas = document.getElementById('myCanvas');
    var slider1 = document.getElementById('slider1');
    slider1.value = 0; 
    var dx = 430;
    var dx2 = 630;
    function draw() { 
        var context = canvas.getContext('2d');
        canvas.width = canvas.width
        var dy = slider1.value;
        
        function DrawLeftLeg(color1){
            context.beginPath();
            context.fillStyle = color1;
            context.moveTo(400,800); context.lineTo(300, 800); context.lineTo(275, 600); context.lineTo(400, 700);
            context.closePath();
            context.fill();
        }
        function DrawRightLeg(color1){
            context.beginPath();
            context.fillStyle = color1;
            context.moveTo(600,800); context.lineTo(700, 800); context.lineTo(725, 600); context.lineTo(600, 700);
            context.closePath();
            context.fill();
        }
        function DrawLowerGengar(color1){
            context.beginPath();
            context.fillStyle = color1;
            context.arc(500,500,250,0, Math.PI, false);
            context.closePath();
            context.lineWidth = 5;
            context.fill();
        }

        function DrawMouth(color1){
            context.beginPath();
            context.fillStyle = color1;
            context.arc(500,500,125,0, Math.PI, false);
            context.closePath();
            context.lineWidth = 5;
            context.fill();
        }

        function DrawUpperGengar(color){
            context.beginPath();
            context.fillStyle = color;
            context.moveTo(250, 500); context.lineTo(275, 50); context.lineTo(350, 200);context.lineTo(400,100);
            context.lineTo(450, 200);context.lineTo(500,100);context.lineTo(550, 200);context.lineTo(600, 100);
            context.lineTo(650, 200);context.lineTo(725, 50);context.lineTo(750, 500);
            context.closePath();
            context.fill();
        }
        
        function DrawLeftEye(color){
            context.beginPath();
            context.fillStyle = color;
            context.arc(400,350,75,0, Math.PI, false);
            context.closePath();
            //context.rotate(45 * Math.PI / 180);
            context.fill();
        }

        function DrawRightEye(color){
            context.beginPath();
            context.fillStyle = color;
            context.arc(600,350,75,0, Math.PI, false);
            context.closePath();
            //context.rotate(135 * Math.PI / 180);
            context.fill();
        }

        function DrawLeftArm(color){
            context.beginPath();
            context.fillStyle = color;
            context.moveTo(275,300); context.lineTo(150,450);context.lineTo(145,460);context.lineTo(155,470);
            context.lineTo(150,480);context.lineTo(160,490);context.lineTo(155,500);context.lineTo(165,510);context.lineTo(275,400);
            context.closePath();
            //context.rotate(135 * Math.PI / 180);
            context.fill();
        }
        
        function DrawRightArm(color){
            context.beginPath();
            context.fillStyle = color;
            context.moveTo(725,300); context.lineTo(850,450);context.lineTo(855,460);context.lineTo(845,470);
            context.lineTo(850,480);context.lineTo(840,490);context.lineTo(845,500);context.lineTo(835,510);context.lineTo(725,400);
            context.closePath();
            //context.rotate(135 * Math.PI / 180);
            context.fill();
        }

        function DrawTongue(color){
            context.save(); 
            context.translate(0, dy);
            context.beginPath();
            context.fillStyle = color;
            context.moveTo(450,200);context.lineTo(450,450);
            context.arc(500,450,50,0, Math.PI, false);
            context.lineTo(550,450);context.lineTo(550,200);
            context.closePath();
            context.fill();
            
            //
        }
        function DrawLeftEyeAnimation(color1){
            context.beginPath();
            context.fillStyle = color1;
            //context.strokeStyle = color2;
            context.arc(dx,370,20,0, 2*Math.PI, false);
            //context.fill();
            context.stroke();

            context.beginPath();
            context.arc(dx2,370,20,0, 2*Math.PI, false);
            //context.fill();
            context.stroke();
            //context.closePath();
            //context.rotate(45 * Math.PI / 180);
            
            dx--;
            if(dx==370){
               dx = 430;
            }
            dx2--;
            if(dx2==570){
               dx2 = 630;
            }
            
           
            window.requestAnimationFrame(draw);
        }
        
        function DrawTeeth(color){
             context.beginPath();
             context.fillStyle = color;
             context.moveTo(375,500); context.lineTo(425,540);context.lineTo(450,520);context.lineTo(550,520);
             context.lineTo(575,540);context.lineTo(625,500);
             context.closePath();
             context.fill()

            
        }

        
            

        DrawRightLeg("purple");
        DrawLeftLeg("purple");
        DrawLowerGengar("purple");
        DrawMouth("red");
        DrawTongue("pink");
        context.restore();
        DrawTeeth("white");
        DrawLeftArm("purple");
        DrawRightArm("purple");
        DrawUpperGengar("purple");
        DrawLeftEye("red");
        DrawRightEye("red");
        DrawLeftEyeAnimation("white");
        //DrawRightEyeAnimation("white");
        
        
    }
    window.requestAnimationFrame(draw);
    //slider1.addEventListener("input",draw); 
    //draw(); 
}
window.onload = setup;