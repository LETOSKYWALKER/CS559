function setup() { "use strict";
  var canvas = document.getElementById('myCanvas');
  //
  var slider1 = document.getElementById('slider1');
  slider1.value = 0;
  var slider2 = document.getElementById('slider2');
  slider2.value = 0;
  var slider3 = document.getElementById('slider3');
  slider3.value = 0;
  var slider4 = document.getElementById('slider4');
  slider4.value = 0;
  var frameCounter = 0;
  var th1 = -35;
  var cf1 = -35;
  var ft1 = -35;
  var th2 = 0;
  var cf2 = 0;
  var ft2 = 0;

  function draw(){
    var ctx = canvas.getContext('2d');
    canvas.width = canvas.width;
    var ftlg = th1*Math.PI/180;
    var ftcf = cf1*Math.PI/180;
    var ftft = ft1*Math.PI/180;
    var bclg = th2*Math.PI/180;
    var bccf = cf2*Math.PI/180;
    var bcft = ft2*Math.PI/180;
    var wist = slider1.value*Math.PI/180;
    var tail = slider2.value*Math.PI/180;
    var ear = slider3.value*Math.PI/180;
    var neck_ = slider4.value*Math.PI/180;

    function animationHandler(){
      if(frameCounter == 0){
        cf1+=2;
        //ft1--;
        th2--;
        ft2++;
        if(cf1==35){
          frameCounter = 1;
          //break;
        }
      }else if(frameCounter == 1){
        
        th1+=2;
        ft1++;
        ft2-=2;
        cf2--;
        if(th1==35){
          frameCounter = 2;
        }
      }else if(frameCounter ==2){
        th1--;
        cf1--;
        cf2+=2;
        //ft2++;
        if(cf2==35){
          cf1= 0;
          ft1=0;
          th1= 0;
          th2 = -35;
          cf2 = 35;
          ft2 = -35;
          frameCounter = 3;
        }
      }else{
        th1--;
        th2 ++;
        cf1 --;
        ft1--;
        ft2 ++;
        cf2--;
        if(cf1==-35){
          frameCounter = 0;
        }
      }
      window.requestAnimationFrame(draw);
    }
      
    function thigh(color){
      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.strokeStyle = "yellow";
      ctx.moveTo(345-345,460-460);ctx.lineTo(375-345, 450-460);ctx.lineTo(405-345, 460-460);ctx.lineTo(405-345, 570-460);
      ctx.lineTo(385-345, 570-460);ctx.lineTo(355-345, 520-460);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      ctx.beginPath();
      ctx.strokeStyle = "yellow";
      ctx.moveTo(375-345, 470-460); ctx.lineTo(365-345, 480-460); ctx.lineTo(375-345, 490-460); ctx.lineTo(385-345, 480-460);
      ctx.lineWidth = 3;
      ctx.closePath();
      ctx.stroke();
    }

    function calf(color){
      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.moveTo(385-385, 550-550);ctx.lineTo(405-385, 560-550); ctx.lineTo(360-385, 650-550); ctx.lineTo(345-385, 645-550);
      ctx.closePath();
      ctx.fill();
    }

    function body(color){
      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.moveTo(195-195,445-445); ctx.lineTo(315-195, 460-445);ctx.lineTo(315-195, 520-445);ctx.lineTo(225-195, 570-445);
      ctx.lineTo(180-195, 545-445);ctx.lineTo(170-195, 525-445);
      ctx.closePath();
      ctx.fill();
    }

    function waist(color){
      ctx.beginPath();
      ctx.moveTo(305-305, 460-460);ctx.lineTo(355-305, 460-460);ctx.lineTo(355-305, 520-460);ctx.lineTo(260-305, 545-460);
      ctx.fillStyle = color;
      ctx.closePath();
      ctx.fill();
    }
    function feet(color){
      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.moveTo(360-360, 650-650); ctx.lineTo(320-360, 660-650); ctx.lineTo(365-360, 660-650);
      ctx.closePath();
      ctx.fill();
    }
    
    function neck(color){
      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.moveTo(175-175,450-450);ctx.lineTo(130-175,500-450);ctx.lineTo(200-175, 520-450); ctx.lineTo(220-175, 460-450);
      ctx.closePath();
      ctx.fill();
    }

    function head(color){
      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.moveTo(170-60,470-500);ctx.lineTo(130-60,510-500);
      ctx.lineTo(70-60,510-500);ctx.lineTo(60-60,500-500); ctx.lineTo(70-60,480-500); ctx.lineTo(80-60,430-500);ctx.lineTo(110-60,400-500);
      ctx.lineTo(150-60,400-500);ctx.lineTo(180-60,430-500);
      ctx.closePath();
      ctx.fill();

      ctx.beginPath();
      ctx.fillStyle= "red";
      ctx.moveTo(100-60, 470-500); ctx.lineTo(110-60, 450-500); ctx.lineTo(135-60, 450-500); ctx.lineTo(125-60, 470-500);
      ctx.closePath();
      ctx.fill();

      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.moveTo(115-60,450-500); ctx.lineTo(120-60, 470-500);ctx.lineTo(125-60,450-500);
      ctx.closePath();
      ctx.fill();

      ctx.beginPath();
      ctx.strokeStyle = "yellow";
      ctx.moveTo(75-60, 455-500); ctx.lineTo(95-60, 435-500);ctx.lineTo(95-60, 415-500);
      ctx.lineWidth = 3;
      ctx.stroke();
    }

    function earAndTail(color){
      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.moveTo(165-165, 415-415); ctx.lineTo(265-165, 315-415);ctx.lineTo(215-165, 340-415);
      ctx.closePath();
      ctx.fill();

      ctx.beginPath();
      ctx.strokeStyle = "yellow";
      ctx.moveTo(215-165, 365-415); ctx.lineTo(240-165, 328-415);
      ctx.lineWidth = 3;
      ctx.stroke();
    }

    ctx.translate(345,445); 
    ctx.save();
    body("black");
    ctx.translate(0,50);
    ctx.save();
    ctx.rotate(ftlg);
    thigh("black");
    ctx.translate(40,110); 
    ctx.save();
    ctx.rotate(ftcf);
    calf("black");
    ctx.translate(-30,100);
    ctx.save();
    ctx.rotate(ftft);
    feet("black");
    ctx.restore();
    ctx.restore();
    ctx.restore();
    ctx.restore();
    ctx.save();
    ctx.translate(-30,0);
    ctx.save();
    ctx.rotate(neck_);
    neck("black");
    ctx.translate(-95,55);
    ctx.save();
    head("black");
    ctx.translate(105,-85);
    ctx.save();
    ctx.rotate(ear);
    earAndTail("black");
    ctx.restore();
    ctx.restore();
    ctx.restore();
    ctx.restore();
    ctx.save();
    ctx.translate(110,15);
    ctx.save();
    ctx.rotate(wist);
    waist("black");
    ctx.translate(40,0);
    ctx.save();
    ctx.rotate(bclg);
    thigh("black");
    ctx.translate(60,0);
    ctx.save();
    ctx.scale(2,1);
    ctx.rotate(tail);
    earAndTail("black");
    ctx.restore();
    //ctx.restore();
    ctx.translate(-20,90);
    ctx.save();
    ctx.rotate(bccf);
    calf("black");
    ctx.translate(-25,100);
    ctx.save();
    ctx.rotate(bcft);
    feet("black");
    ctx.restore();
    ctx.restore();
    ctx.restore();
    ctx.restore();
    ctx.restore();
    animationHandler();
    //window.requestAnimationFrame(draw);
  }
  /*slider1.addEventListener("input",draw);
  slider2.addEventListener("input",draw);
  slider3.addEventListener("input",draw);
  slider4.addEventListener("input",draw);*/
  window.requestAnimationFrame(draw);
}
window.onload = setup;